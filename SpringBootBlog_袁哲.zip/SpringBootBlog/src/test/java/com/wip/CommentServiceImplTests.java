package com.wip;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import com.github.pagehelper.PageInfo;
import com.wip.dao.CommentDao;
import com.wip.dao.ContentDao;
import com.wip.dao.TutorialsDao;
import com.wip.dto.cond.CommentCond;
import com.wip.model.CommentDomain;
import com.wip.model.ContentDomain;
import com.wip.model.TutorialsDomain;
import com.wip.service.article.ContentService;
import com.wip.service.comment.CommentService;
import com.wip.utils.DateKit;
import com.wip.exception.BusinessException;
@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class CommentServiceImplTests{ 
    @Autowired
    private CommentService commentService;

    @Autowired
    private CommentDao commentDao;

    //事先添加的数据
//    INSERT INTO `t_comments` (  
//    		  `tuid`,  
//    		  `created`,  
//    		  `author`,  
//    		  `authorId`,  
//    		  `ownerId`,  
//    		  `mail`,  
//    		  `url`,  
//    		  `ip`,  
//    		  `agent`,  
//    		  `content`,  
//    		  `type`,  
//    		  `status`,  
//    		  `parent`  
//    		) VALUES (  
//    		  7,  
//    		  UNIX_TIMESTAMP(),  
//    		  'John Doe', 
//    		  1, 
//    		  1, -- 拥有者ID（可能是文章、帖子等的ID）  
//    		  'john.doe@example.com', -- 邮箱  
//    		  'http://example.com', -- URL  
//    		  '192.168.1.1', -- IP地址  
//    		  'Mozilla/5.0 ...',
//    		  '这是评论的内容。', -- 评论内容  
//    		  'comment', -- 类型，这里保持默认值  
//    		  'approved',   
//    		  0
//    		);
    
    
    @Test
    public void AddComment() {
        CommentDomain commentDomain = new CommentDomain();
        commentDomain.setCid(34);
        commentDomain.setContent("This is a test comment");
        commentDomain.setAuthor("Test Author");
        commentDomain.setEmail("test@example.com");
        commentDomain.setCreated(DateKit.getCurrentUnixTime());

        commentService.addComment(commentDomain);
    }

    @Test
    public void GetCommentsByCId() {
        List<CommentDomain> comments = commentService.getCommentsByCId(17);
        assertNotNull(comments);
        assertEquals(1, comments.size());
    }

    @Test
    public void GetCommentByTuId() {
        List<CommentDomain> comments = commentService.getCommentByTuId(18);
        assertNotNull(comments);
        assertEquals(1, comments.size());
        assertEquals("这是评论的内容。", comments.get(0).getContent());
    }

    @Test
    public void GetCommentsByCond() {
        PageInfo<CommentDomain> pageInfo = commentService.getCommentsByCond(new CommentCond(), 1, 10);
        assertNotNull(pageInfo);
        assertEquals(2, pageInfo.getList().size());
    }

    @Test
    public void GetCommentById() {
        CommentDomain retrievedComment = commentService.getCommentById(17);
        assertNotNull(retrievedComment);
        assertEquals("这是评论的内容。", retrievedComment.getContent());
    }

    @Test
    public void UpdateCommentStatus() {
        commentService.updateCommentStatus(17, "approved");

        CommentDomain updatedComment = commentDao.getCommentById(17);
        assertNotNull(updatedComment);
        assertEquals("approved", updatedComment.getStatus());
    }

    @Test
    public void DeleteComment() {
        commentService.deleteComment(17);

        CommentDomain deletedComment = commentDao.getCommentById(17);
        assertNull(deletedComment);
    }
}

