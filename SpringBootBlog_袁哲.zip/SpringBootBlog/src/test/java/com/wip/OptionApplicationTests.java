package com.wip;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.wip.dao.OptionDao;
import com.wip.exception.BusinessException;
import com.wip.model.OptionsDomain;
import com.wip.service.option.impl.OptionServiceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class OptionApplicationTests {
	@Autowired
    private OptionServiceImpl optionServiceImpl;

    
    @Test
    public void GetOptions() {
        List<OptionsDomain> options = optionServiceImpl.getOptions();
        assertNotNull(options);
        assertTrue(options.size() > 0);
    }

    @Test
    public void SaveOptions() {
        Map<String, String> optionsMap = new HashMap<>();
        optionsMap.put("siteName", "UpdatedSiteName");
        optionsMap.put("siteUrl", "http://www.update.com");

        optionServiceImpl.saveOptions(optionsMap);
        OptionsDomain updatedOption1 = optionServiceImpl.getOptionByName("siteName");
        OptionsDomain updatedOption2 = optionServiceImpl.getOptionByName("siteUrl");
        assertNotNull(updatedOption1);
        assertNotNull(updatedOption2);
    }

    @Test
    public void UpdateOptionByName() {
        optionServiceImpl.updateOptionByName("site_description", "NEWVALUE");
        OptionsDomain updatedOption = optionServiceImpl.getOptionByName("site_description");
        assertNotNull(updatedOption);
        assertEquals("NEWVALUE", updatedOption.getValue());
    }

    @Test
    public void GetOptionByName() {
        OptionsDomain option = optionServiceImpl.getOptionByName("site_title");
        assertNotNull(option);
        assertEquals("Seiryo", option.getValue());
    }
}

