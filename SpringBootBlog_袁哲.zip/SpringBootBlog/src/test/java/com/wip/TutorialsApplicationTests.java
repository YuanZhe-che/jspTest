package com.wip;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageInfo;
import com.wip.dao.CommentDao;
import com.wip.dao.MetaDao;
import com.wip.dao.RelationShipDao;
import com.wip.dao.TutorialsDao;
import com.wip.dto.cond.TutorialsCond;
import com.wip.exception.BusinessException;
import com.wip.model.CommentDomain;
import com.wip.model.MetaDomain;
import com.wip.model.RelationShipDomain;
import com.wip.model.TutorialsDomain;
import com.wip.service.tutorials.TutorialsService;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class TutorialsApplicationTests {

    @Autowired
    private TutorialsService tutorialsService;

    @Autowired
    private TutorialsDao tutorialsDao;

    @Autowired
    private MetaDao metaDao;

    @Autowired
    private RelationShipDao relationShipDao;

    @Autowired
    private CommentDao commentDao;

//通过系统插入数据tuid(7)
//  INSERT INTO `t_tutorials` (`title`,`titlePic`,`slug`,`created`,`modified`, `content`,`authorId`,`type`,`status`,`tags`,`categories`,`hits`,  
//  		  `commentsNum`, `allowComment`,`allowPing`, `allowFeed`  
//  		) VALUES (  
//  		  '特色',NULL,NULL, 1725207665,0,'《tetstt》',0,  'post', 'publish', '教程', '默认分类',0, 0, 1,1,1 
//        );
    
    @Test
    public void AddTutorial() {
        TutorialsDomain tutorialsDomain = new TutorialsDomain();
        tutorialsDomain.setTitle("Sample Tutorial");
        tutorialsDomain.setContent("Sample Content");
        tutorialsDomain.setTuid(1);
        tutorialsDomain.setTags("教程");
        tutorialsDomain.setCategories("默认分类");

        tutorialsService.addTutorial(tutorialsDomain);

        TutorialsDomain retrievedTutorial = tutorialsDao.getTutorialById(1);
        assertNotNull(retrievedTutorial);
        assertEquals("Sample Tutorial", retrievedTutorial.getTitle());
        assertEquals("Sample Content", retrievedTutorial.getContent());
        assertEquals("教程", retrievedTutorial.getTags());
        assertEquals("默认分类", retrievedTutorial.getCategories());
    }

    @Test
    public void GetTutorialById() {
        TutorialsDomain retrievedTutorial = tutorialsService.getTutorialById(7);
        assertNotNull(retrievedTutorial);
        assertEquals("特色", retrievedTutorial.getTitle());
    }

    @Test
    public void UpdateTutorialById() {
        TutorialsDomain tutorialsDomain = new TutorialsDomain();
        tutorialsDomain.setTuid(7);
   
        tutorialsDomain.setTitle("Updated Title");
        tutorialsDomain.setContent("Updated Content");
        tutorialsService.updateTutorialById(tutorialsDomain);
        TutorialsDomain updatedTutorial = tutorialsDao.getTutorialById(7);
        assertEquals("Updated Title", updatedTutorial.getTitle());
        assertEquals("Updated Content", updatedTutorial.getContent());
    }

    @Test
    public void GetTutorialByCond() {
        TutorialsCond tutorialsCond = new TutorialsCond();

        PageInfo<TutorialsDomain> pageInfo = tutorialsService.getTutorialByCond(tutorialsCond, 1, 10);
        assertNotNull(pageInfo);
        assertEquals(1, pageInfo.getList().size());
    }

    @Test
    public void DeleteTutorialById() {
        tutorialsService.deleteTutorialsById(7);

        TutorialsDomain deletedTutorial = tutorialsDao.getTutorialById(7);
        assertNull(deletedTutorial);
    }

    @Test
    public void UpdateTutorialsById() {
        TutorialsDomain tutorialsDomain = new TutorialsDomain();
        tutorialsDomain.setTuid(7);
        tutorialsDomain.setTitle("Updated Title");
        tutorialsService.updateTutorialsById(tutorialsDomain);

        TutorialsDomain updatedTutorial = tutorialsDao.getTutorialById(7);
        assertEquals("Updated Title", updatedTutorial.getTitle());
    }

    @Test
    public void GetTutorialByCategory() {
        List<TutorialsDomain> tutorials = tutorialsService.getTutorialsByCategory("默认分类");
        assertNotNull(tutorials);
        assertEquals(1, tutorials.size());
        assertEquals("默认分类", tutorials.get(0).getCategories());
    }

    @Test
    public void GetTutorialByTags() {
        MetaDomain tags = new MetaDomain();
        tags.setMid(55);
        tags.setName("教程");

        List<TutorialsDomain> tutorials = tutorialsService.getTutorialsByTags(tags);
        assertNotNull(tutorials);
        assertEquals(1, tutorials.size());
        assertEquals("教程", tutorials.get(0).getTags());
    }
}