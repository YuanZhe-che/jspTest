package com.wip;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.wip.dao.CommentDao;
import com.wip.dao.ContentDao;
import com.wip.dao.TutorialsDao;
import com.wip.dao.MetaDao;
import com.wip.dao.AttAchDao;
import com.wip.dto.StatisticsDto;
import com.wip.dto.cond.CommentCond;
import com.wip.dto.cond.ContentCond;
import com.wip.dto.cond.TutorialsCond;
import com.wip.model.AttAchDomain;
import com.wip.model.CommentDomain;
import com.wip.model.ContentDomain;
import com.wip.model.MetaDomain;
import com.wip.model.TutorialsDomain;
import com.wip.service.site.impl.SiteServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class SiteApplicationTests {

    @Autowired
    private SiteServiceImpl siteService;

    @Autowired
    private CommentDao commentDao;

    @Autowired
    private ContentDao contentDao;

    @Autowired
    private TutorialsDao tutorialsDao;

    @Autowired
    private MetaDao metaDao;

    @Autowired
    private AttAchDao attAchDao;

    @Test
    public void GetComments() {
        List<CommentDomain> result = siteService.getComments(5);

        // 验证结果
        assertNotNull(result);
        assertEquals("这是评论的内容。", result.get(0).getContent());
    }

    @Test
    public void GetNewArticles() {
        List<ContentDomain> result = siteService.getNewArticles(5);

        // 验证结果
        assertNotNull(result);
        assertEquals("test", result.get(0).getTitle());
    }

    @Test
    public void GetNewTutorials() {
        List<TutorialsDomain> result = siteService.getNewTutorials(5);

        // 验证结果
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("特色", result.get(0).getTitle());
    }

    @Test
    public void GetStatistics() {
        // 调用服务方法
        StatisticsDto result = siteService.getStatistics();

        // 验证结果
        assertNotNull(result);
        //在数据库中存在相应条数据
        assertEquals(1L, result.getArticles().longValue());
        assertEquals(2L, result.getComments().longValue());
        assertEquals(1L, result.getTutorials().longValue());
        assertEquals(2L, result.getLinks().longValue());  
        assertEquals(1L, result.getAttachs().longValue()); 
    }
}

