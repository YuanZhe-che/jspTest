package com.wip;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import com.github.pagehelper.PageInfo;
import com.wip.dao.CommentDao;
import com.wip.dao.ContentDao;
import com.wip.dao.RelationShipDao;
import com.wip.dto.cond.ContentCond;
import com.wip.model.CommentDomain;
import com.wip.model.ContentDomain;
import com.wip.model.MetaDomain;
import com.wip.model.RelationShipDomain;
import com.wip.service.article.ContentService;
import com.wip.service.meta.MetaService;
import org.springframework.test.context.junit4.SpringRunner;

import com.wip.exception.BusinessException;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class ContentApplicationTest {

	@Autowired
    private ContentService contentService;

    @Autowired
    private ContentDao contentDao;
//通过系统插入数据
//    INSERT INTO `t_contents` (`title`,`titlePic`,`slug`,`created`,`modified`, `content`,`authorId`,`type`,`status`,`tags`,`categories`,`hits`,  
//    		  `commentsNum`, `allowComment`,`allowPing`, `allowFeed`  
//    		) VALUES (  
//    		  'test',NULL,NULL, 1724737305,0,'《------TEST-----------》',0,  'post', 'publish', '文本', '文章',0, 0, 1,1,1 
//          );
    @Test
    public void AddArticle() {
        ContentDomain contentDomain = new ContentDomain();
        contentDomain.setTitle("Sample Title");
        contentDomain.setContent("Sample Content");
        contentDomain.setTags("文本");
        contentDomain.setCategories("文章");
        contentDomain.setType("article");
        contentDomain.setStatus("publish");
        contentDomain.setAllowComment(1);

        contentService.addArticle(contentDomain);

        ContentDomain retrievedArticle = contentDao.getArticleById(1);
        assertNotNull(retrievedArticle);
        assertEquals("Sample Title", retrievedArticle.getTitle());
        assertEquals("Sample Content", retrievedArticle.getContent());
        assertEquals("文章", retrievedArticle.getCategories());
    }

    @Test
    public void GetArticleById() {
        ContentDomain retrievedArticle = contentService.getArticleById(34);
        assertNotNull(retrievedArticle);
        assertEquals("test", retrievedArticle.getTitle());
    }

    @Test
    public void UpdateArticleById() {
        ContentDomain contentDomain = new ContentDomain();
        contentDomain.setCid(34);
        contentDomain.setTitle("Updated Title");
        contentDomain.setContent("Updated Content");
        contentService.updateArticleById(contentDomain);

        ContentDomain updatedArticle = contentDao.getArticleById(34);
        assertEquals("Updated Title", updatedArticle.getTitle());
        assertEquals("Updated Content", updatedArticle.getContent());
    }

    @Test
    public void GetArticlesByCond() {
        ContentCond contentCond = new ContentCond();
        PageInfo<ContentDomain> pageInfo = contentService.getArticlesByCond(contentCond, 1, 10);
        assertNotNull(pageInfo);
        assertEquals(1, pageInfo.getList().size());
    }

    @Test
    public void DeleteArticleById() {
        ContentDomain contentDomain = new ContentDomain();
        contentDomain.setCid(34);
        contentService.deleteArticleById(34);
        ContentDomain deletedArticle = contentDao.getArticleById(34);
        assertNull(deletedArticle);
    }

    @Test
    public void UpdateContentByCid() {
        ContentDomain contentDomain = new ContentDomain();
        contentDomain.setCid(34);
        contentDomain.setTitle("Updated Title");
        contentService.updateContentByCid(contentDomain);

        ContentDomain updatedArticle = contentDao.getArticleById(34);
        assertEquals("Updated Title", updatedArticle.getTitle());
    }

    @Test
    public void GetArticleByCategory() {
        List<ContentDomain> articles = contentService.getArticleByCategory("文章");
        assertNotNull(articles);
        assertEquals(1, articles.size());
        assertEquals("文章", articles.get(0).getCategories());
    }

    @Test
    public void GetArticleByTags() {
        MetaDomain tags = new MetaDomain();
        //事先插入数据mid(56),cid(34)
        tags.setMid(56);
        tags.setName("文本");
        List<ContentDomain> articles = contentService.getArticleByTags(tags);
        assertNotNull(articles);
        assertEquals(1, articles.size());
        assertEquals("文本", articles.get(0).getTags());
    }
}