package com.wip;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import com.github.pagehelper.PageInfo;
import com.wip.dao.AttAchDao;
import com.wip.dto.AttAchDto;
import com.wip.model.AttAchDomain;
import com.wip.service.attach.AttAchService;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class AttachApplicationTests {

    @Autowired
    private AttAchService attAchService;

    @Autowired
    private AttAchDao attAchDao;

    @Test
    public void AddAttAch() {
        AttAchDomain attAchDomain = new AttAchDomain();
        attAchDomain.setId(1);
        attAchDomain.setFname("sample.txt");
        attAchDomain.setFtype("text");
        attAchDomain.setFkey("http://example.com/sample.txt");
        attAchDomain.setAuthorId(1);
        attAchService.addAttAch(attAchDomain);
    }

    @Test
    public void GetAtts() {
        AttAchDomain attAchDomain1 = new AttAchDomain();
        attAchDomain1.setFname("sample1.txt");
        attAchDomain1.setFtype("text");
        attAchDomain1.setFkey("http://example.com/sample1.txt");
        attAchDomain1.setAuthorId(1);
        attAchDao.addAttAch(attAchDomain1);

        PageInfo<AttAchDto> pageInfo = attAchService.getAtts(1, 10);
        assertNotNull(pageInfo);
        assertEquals(2, pageInfo.getList().size());
    }

    @Test
    public void GetAttAchById() {
//        AttAchDomain attAchDomain = new AttAchDomain();
//        attAchDomain.setId(1);
//        attAchDomain.setFname("sample.txt");
//        attAchDomain.setFtype("text");
//        attAchDomain.setFkey("http://example.com/sample.txt");
//        attAchDomain.setAuthorId(1);
//        attAchDao.addAttAch(attAchDomain);

        AttAchDto retrievedAttAch = attAchService.getAttAchById(47);
        assertNotNull(retrievedAttAch);
    }

    @Test
    public void DeleteAttAch() {
        AttAchDomain attAchDomain = new AttAchDomain();
        attAchDomain.setId(1);
        attAchDomain.setFname("sample.txt");
        attAchDomain.setFtype("text");
        attAchDomain.setFkey("http://example.com/sample.txt");
        attAchDomain.setAuthorId(1);
        attAchDao.addAttAch(attAchDomain);

        attAchService.deleteAttAch(1);

        AttAchDto deletedAttAch = attAchService.getAttAchById(1);
        assertNull(deletedAttAch);
    }
}