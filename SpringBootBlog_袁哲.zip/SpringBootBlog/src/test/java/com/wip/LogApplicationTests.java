package com.wip;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import com.github.pagehelper.PageInfo;
import com.wip.dao.LogDao;
import com.wip.model.LogDomain;
import com.wip.service.log.LogService;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class LogApplicationTests {

    @Autowired
    private LogService logService;

    @Test
    public void AddLog() {
        String action = "登陆后台";
        String data = "admin用户";
        String ip = "0:0:0:0:0:0:0:1";
        Integer authorId = 1;

        logService.addLog(action, data, ip, authorId);
    }

    @Test
    public void GetLogs() {
        int pageNum = 1;
        int pageSize = 10;
        logService.getLogs(pageNum, pageSize);
        PageInfo<LogDomain> pageInfo = logService.getLogs(1, 10);
        assertNotNull("PageInfo 不能为 null", pageInfo);
    }
}