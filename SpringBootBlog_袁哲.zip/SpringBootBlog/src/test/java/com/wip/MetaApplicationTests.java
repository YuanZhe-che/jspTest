package com.wip;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.wip.dao.MetaDao;
import com.wip.dao.RelationShipDao;
import com.wip.dto.MetaDto;
import com.wip.exception.BusinessException;
import com.wip.model.MetaDomain;
import com.wip.service.article.ContentService;
import com.wip.service.meta.impl.MetaServiceImpl;

import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class MetaApplicationTests {
	@Autowired
    private MetaServiceImpl metaServiceImpl;
	
	@Autowired
	private MetaDao metaDao;
    @Autowired
    private RelationShipDao relationShipDao;
//系统插入数据
//mid(55),name(教程),type(tag)
    @Test
    public void SaveMeta() {
        String type = "test";
        String name = "test";
        Integer mid = 55; 
        metaServiceImpl.saveMeta(type, name, mid);
        MetaDomain meta = metaDao.getMetaByName(type, name);
        assertNotNull(meta);
        assertEquals(name, meta.getName());
        assertEquals(type, meta.getType());
    }

    @Test
    public void GetMetaList() {
        List<MetaDto> metaList = metaServiceImpl.getMetaList("category", "sort asc", 10);
        assertNotNull(metaList);
        assertFalse(metaList.isEmpty());
    }

    @Test
    public void AddMetas() {
        Integer cid = 34;
        String names = "BatchMeta1,BatchMeta2";
        String type = "tag";
        metaServiceImpl.addMetas(cid, names, type);

        MetaDomain meta1 = metaDao.getMetaByName(type, "BatchMeta1");
        MetaDomain meta2 = metaDao.getMetaByName(type, "BatchMeta2");
        assertNotNull(meta1);
        assertNotNull(meta2);
        assertEquals("BatchMeta1", meta1.getName());
        assertEquals("BatchMeta2", meta2.getName());
    }
    @Test
    public void AddTMetas() {
        Integer tuid = 1;
        String names = "BatchMeta1,BatchMeta2";
        String type = "tag";
        metaServiceImpl.addTMetas(tuid, names, type);

        MetaDomain meta1 = metaDao.getMetaByName(type, "BatchMeta1");
        MetaDomain meta2 = metaDao.getMetaByName(type, "BatchMeta2");
        assertNotNull(meta1);
        assertNotNull(meta2);
        assertEquals("BatchMeta1", meta1.getName());
        assertEquals("BatchMeta2", meta2.getName());
    }

    @Test
    public void DeleteMetaById() {
        Integer mid = 56;
        metaServiceImpl.deleteMetaById(mid);
        MetaDomain meta = metaDao.getMetaById(mid);
        assertNull(meta);
    }

    @Test
    public void GetMetaByName() {
        MetaDomain meta = metaServiceImpl.getMetaByName("tag", "教程");
        assertNotNull(meta);
        assertEquals("tag", meta.getType());
    }

    @Test
    public void SaveTOrUpdate() {
        Integer tuid = 7;
        String name = "UpdatedMeta";
        String type = "category";
        metaServiceImpl.saveTOrUpdate(tuid, name, type);
        MetaDomain meta = metaDao.getMetaByName(type, name);
        assertNotNull(meta);
        assertEquals(name, meta.getName());
        Long count = relationShipDao.getCountByTuId(tuid, meta.getMid());
        assertTrue(count > 0);
    }
    @Test
    public void SaveOrUpdate() {
        Integer cid = 34;
        String name = "SaveOrUpdateMeta";
        String type = "tag";
        metaServiceImpl.saveOrUpdate(cid, name, type);
        MetaDomain meta = metaDao.getMetaByName(type, name);
        assertNotNull(meta);
        assertEquals(name, meta.getName());
        Long count = relationShipDao.getCountById(cid, meta.getMid());
        assertTrue(count > 0);
    }

    @Test
    public void UpdateMeta() {
        MetaDomain meta = metaDao.getMetaById(55);
        meta.setDescription("Updated description");

        metaServiceImpl.updateMeta(meta);

        MetaDomain updatedMeta = metaDao.getMetaById(55);
        assertNotNull(updatedMeta);
        assertEquals("Updated description", updatedMeta.getDescription());
    }


    @Test
    public void GetMetasCountByType() {
        Long count = metaServiceImpl.getMetasCountByType("category");
        assertNotNull(count);
        assertTrue(count > 0);
    }
}
