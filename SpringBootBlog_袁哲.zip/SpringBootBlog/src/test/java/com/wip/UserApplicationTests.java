package com.wip;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.wip.exception.BusinessException;
import com.wip.model.UserDomain;
import com.wip.service.user.impl.UserServiceImpl;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class UserApplicationTests {

	@Autowired
    private UserServiceImpl userServiceImpl;

	@Test
    public void LoginSuccess() {
        String username = "admin";
        String password = "123456"; 

        UserDomain user = userServiceImpl.login(username, password);

        assertNotNull(user);
        assertEquals((Integer)1, user.getUid());
        assertEquals("admin", user.getUsername());
    }

    @Test(expected = BusinessException.class)
    public void LoginFailure() {
        String username = "admin";
        // 错误密码
        String password = "wrongpassword"; 

        userServiceImpl.login(username, password);
    }

    @Test
    public void GetUserInfoById() {
        UserDomain user = userServiceImpl.getUserInfoById(1);
        assertNotNull(user);
        assertEquals((Integer)1, user.getUid());
        assertEquals("864655735@qq.com", user.getEmail());
    }

    @Test
    public void UpdateUserInfo() {
        UserDomain user = new UserDomain();
        user.setUid(1);
        user.setUsername("updatedadmin");
        user.setEmail("updatedemail@example.com");
        userServiceImpl.updateUserInfo(user);
        UserDomain updatedUser = userServiceImpl.getUserInfoById(1);
        assertNotNull(updatedUser);
        assertEquals("updatedemail@example.com", updatedUser.getEmail());
    }
}
