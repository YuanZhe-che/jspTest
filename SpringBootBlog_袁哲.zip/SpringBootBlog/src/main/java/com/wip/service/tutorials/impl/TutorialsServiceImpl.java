package com.wip.service.tutorials.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wip.constant.ErrorConstant;
import com.wip.constant.Types;
import com.wip.constant.WebConst;
import com.wip.dao.CommentDao;
import com.wip.dao.RelationShipDao;
import com.wip.dao.TutorialsDao;
import com.wip.dto.cond.TutorialsCond;
import com.wip.exception.BusinessException;
import com.wip.model.CommentDomain;
import com.wip.model.ContentDomain;
import com.wip.model.MetaDomain;
import com.wip.model.RelationShipDomain;
import com.wip.model.TutorialsDomain;
import com.wip.service.meta.MetaService;
import com.wip.service.tutorials.TutorialsService;

@Service
public class TutorialsServiceImpl implements TutorialsService{
	@Autowired
    private MetaService metaService;

    @Autowired
    private RelationShipDao relationShipDao;

    @Autowired
    private CommentDao commentDao;
    
    @Autowired
    private TutorialsDao tutorialsDao;
    
    @Transactional
    @Override
    @CacheEvict(value = {"tutorialsCache", "tutorialsCaches"}, allEntries = true, beforeInvocation = true)
	public void addTutorial(TutorialsDomain tutorialsDomain) {
    	if (null == tutorialsDomain)
            throw BusinessException.withErrorCode(ErrorConstant.Common.PARAM_IS_EMPTY);

        if (StringUtils.isBlank(tutorialsDomain.getTitle()))
            throw BusinessException.withErrorCode(ErrorConstant.Article.TITLE_CAN_NOT_EMPTY);

        if (tutorialsDomain.getTitle().length() > WebConst.MAX_TITLE_COUNT)
            throw BusinessException.withErrorCode(ErrorConstant.Article.TITLE_IS_TOO_LONG);

        if (StringUtils.isBlank(tutorialsDomain.getContent()))
            throw BusinessException.withErrorCode(ErrorConstant.Article.CONTENT_CAN_NOT_EMPTY);

        if (tutorialsDomain.getContent().length() > WebConst.MAX_CONTENT_COUNT)
            throw BusinessException.withErrorCode(ErrorConstant.Article.CONTENT_IS_TOO_LONG);

        // 取到标签和分类
        String tags = tutorialsDomain.getTags();
        String categories = tutorialsDomain.getCategories();

        // 添加教程
        tutorialsDao.addTutorial(tutorialsDomain);

        // 添加分类和标签
        int tuid = tutorialsDomain.getTuid();
        metaService.addTMetas(tuid, tags, Types.TAG.getType());
        metaService.addTMetas(tuid, categories, Types.CATEGORY.getType());
		
	}
    @Override
    @Cacheable(value = "tutorialsCache", key = "'tutorialsById_' + #p0")
	public TutorialsDomain getTutorialById(Integer tuid) {
    	if (null == tuid)
            throw BusinessException.withErrorCode(ErrorConstant.Common.PARAM_IS_EMPTY);
        return tutorialsDao.getTutorialById(tuid);
	}

    @Override
    @Transactional
    @CacheEvict(value = {"TutorialsCache", "TutorialsCaches"}, allEntries = true, beforeInvocation = true)
	public void updateTutorialById(TutorialsDomain tutorialsDomain) {
    	// 标签和分类
        String tags = tutorialsDomain.getTags();
        String categories = tutorialsDomain.getCategories();

        // 更新教程
        tutorialsDao.updateTutorialById(tutorialsDomain);
        int tuid = tutorialsDomain.getTuid();
        relationShipDao.deleteRelationShipByTuid(tuid);
        metaService.addTMetas(tuid,tags,Types.TAG.getType());
        metaService.addTMetas(tuid,categories,Types.CATEGORY.getType());
	}

    @Override
    @Cacheable(value = "TutorialsCaches", key = "'TutorialsByCond_' + #p1 + 'type_' + #p0.type")
	public PageInfo<TutorialsDomain> getTutorialByCond(TutorialsCond tutorialsCond, int page, int limit){
    	if (null == tutorialsCond)
            throw BusinessException.withErrorCode(ErrorConstant.Common.PARAM_IS_EMPTY);
        PageHelper.startPage(page,limit);
        List<TutorialsDomain> tutorials = tutorialsDao.getTutorialsByCond(tutorialsCond);
        PageInfo<TutorialsDomain> pageInfo = new PageInfo<>(tutorials);
        return pageInfo;
	}

	@Override
    @Transactional
    @CacheEvict(value = {"tutorialsCache","tutorialsCaches"},allEntries = true, beforeInvocation = true)
	public void deleteTutorialsById(Integer tuid) {
		 if (null == tuid)
	            throw BusinessException.withErrorCode(ErrorConstant.Common.PARAM_IS_EMPTY);
	        // 删除文章
		 	tutorialsDao.deleteTutorialsById(tuid);

	        // 同时要删除该 文章下的所有评论
	        List<CommentDomain> comments = commentDao.getCommentByTuId(tuid);
	        if (null != comments && comments.size() > 0) {
	            comments.forEach(comment -> {
	                commentDao.deleteComment(comment.getCoid());
	            });
	        }

	        // 删除标签和分类关联
	        List<RelationShipDomain> relationShips = relationShipDao.getRelationShipByTuid(tuid);
	        if (null != relationShips && relationShips.size() > 0) {
	            relationShipDao.deleteRelationShipByTuid(tuid);
	        }
	}
	@Override
	@CacheEvict(value = {"tutorialsCache","tutorialsCaches"}, allEntries = true, beforeInvocation = true)
	public void updateTutorialsById(TutorialsDomain tutorialsDomain) {
		if (null != tutorialsDomain && null != tutorialsDomain.getTuid()) {
			tutorialsDao.updateTutorialById(tutorialsDomain);
        }
	}
	@Override
	@Cacheable(value = "tutorialsCache", key = "'tutorialsByCategory_' + #p0")
	public List<TutorialsDomain> getTutorialsByCategory(String category) {
		if (null == category)
		      throw BusinessException.withErrorCode(ErrorConstant.Common.PARAM_IS_EMPTY);
		return tutorialsDao.getTutorialsByCategory(category);
	}
	@Override
	@Cacheable(value = "tutorialsCache", key = "'tutorialsByTags_'+ #p0")
	public List<TutorialsDomain> getTutorialsByTags(MetaDomain tags) {
		if (null == tags)
		       throw BusinessException.withErrorCode(ErrorConstant.Common.PARAM_IS_EMPTY);
		   List<RelationShipDomain> relationShip = relationShipDao.getRelationShipByMid(tags.getMid());
		   if (null != relationShip && relationShip.size() > 0) {
		       return tutorialsDao.getArticleByTags(relationShip);
		}
		   return null;
	}

	

}
