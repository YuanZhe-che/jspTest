package com.wip.service.tutorials;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.github.pagehelper.PageInfo;
import com.wip.dto.cond.ContentCond;
import com.wip.dto.cond.TutorialsCond;
import com.wip.model.ContentDomain;
import com.wip.model.MetaDomain;
import com.wip.model.RelationShipDomain;
import com.wip.model.TutorialsDomain;

public interface TutorialsService {
	 /**
     * 添加教程
     * @param contentDomain
     */
    void addTutorial(TutorialsDomain tutorialsDomain);

    /**
     * 根据编号获取教程
     * @param cid
     * @return
     */
    TutorialsDomain getTutorialById(Integer tuid);

    /**
     * 更新教程
     * @param contentDomain
     */
    void updateTutorialById(TutorialsDomain tutorialsDomain);

    /**
     * 根据条件获取文章列表
     * @param contentCond
     * @param page
     * @param limit
     * @return
     */
    PageInfo<TutorialsDomain> getTutorialByCond(TutorialsCond tutorialsCond, int page, int limit);

    /**
     * 删除教程
     * @param tuid
     */
    void deleteTutorialsById(Integer tuid);

    /**
     * 添加文章点击量
     * @param content
     */
    void updateTutorialsById(TutorialsDomain tutorialsDomain);

    /**
     * 通过分类名获取教程
     * @param category
     * @return
     */
    List<TutorialsDomain> getTutorialsByCategory(String category);

    /**
     * 通过标签获取文章
     * @param cid
     * @return
     */
    List<TutorialsDomain> getTutorialsByTags(MetaDomain tags);
}
