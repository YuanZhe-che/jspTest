/**
 * Created by IntelliJ IDEA.
 * User: Kyrie
 * DateTime: 2018/8/3 16:30
 **/
package com.wip.dto;

/**
 * 公共属性的类
 */
public class BaseDto {

    /**
     * 用户名
     */
    private String userName;

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }
}
