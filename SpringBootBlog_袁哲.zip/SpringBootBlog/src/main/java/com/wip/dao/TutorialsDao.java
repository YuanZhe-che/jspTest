package com.wip.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.wip.dto.cond.ContentCond;
import com.wip.dto.cond.TutorialsCond;
import com.wip.model.ContentDomain;
import com.wip.model.RelationShipDomain;
import com.wip.model.TutorialsDomain;

/**
 * 教程相关Dao接口
 */
@Mapper
public interface TutorialsDao {
	 /**
     * 添加教程
     * @param contentDomain
     */
    void addTutorial(TutorialsDomain tutorialsDomain);

    /**
     * 根据编号获取教程
     * @param cid
     * @return
     */
    TutorialsDomain getTutorialById(Integer tuid);

    /**
     * 更新教程
     * @param contentDomain
     */
    void updateTutorialById(TutorialsDomain tutorialsDomain);

    /**
     * 根据条件获取教程列表
     * @param contentCond
     * @return
     */
    List<TutorialsDomain> getTutorialsByCond(TutorialsCond tutorialsCond);

    /**
     * 删除教程
     * @param tuid
     */
    void deleteTutorialsById(Integer tuid);

    /**
     * 获取教程总数
     * @return
     */
    Long getTutorialsCount();

    /**
     * 通过分类名获取教程
     * @param category
     * @return
     */
    List<TutorialsDomain> getTutorialsByCategory(@Param("category") String category);

    /**
     * 通过标签获取文章
     * @param tuid
     * @return
     */
    List<TutorialsDomain> getArticleByTags(List<RelationShipDomain> tuid);
}
